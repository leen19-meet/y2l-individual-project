
True Type Font: Roman Font 7 version 1.0


EULA
-==-
The font Roman Font 7 is freeware for home use only.


DESCRIPTION
-=========-
The font has roman numbers from 1 to 12.
It was created special for freeware android application "Roman Clock Live Wallpaper-7".
https://play.google.com/store/apps/details?id=com.style_7.romeclocklivewallpaper_7
Use symbols "{|}" to type numbers: 10,11,12.

Files in roman_font_7.zip:
       	readme.txt     		this file;
        roman_font_7.ttf 	regular font;
	roman_font_7_screen.png	preview image.

Please visit http://www.styleseven.com/ to download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.

Use this link to buy the license ($24.95): http://store.esellerate.net/s.aspx?s=STR0331655240
Please enter font name in web form.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: Frbtuary 24 2015